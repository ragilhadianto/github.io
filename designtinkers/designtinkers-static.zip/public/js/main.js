//slider
$(".slider").slick({
    dots: false,
    infinite: true,
    speed: 500,
    autoplay: false,
    autoplaySpeed: 2000,
    appendDots: false,
    slidesToShow: 3,
    slidesToScroll: 3,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow:1.3,
          slidesToScroll:1,
          arrows: false,
          infinite: false,
        }
      }
    ]
  });
$(".slider__text").slick({
    dots: false,
    infinite: true,
    speed: 500,
    autoplay: false,
    autoplaySpeed: 2000,
    appendDots: false,
    slidesToShow: 1,
    slidesToScroll: 1,
    adaptiveHeight: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow:1,
          slidesToScroll:1,
          arrows: false,
          infinite: false,
        }
      }
    ]
  });


   // smooth goto
   $(".btnGoTo").click(function(e) {
    var getId = $(this).attr('data-id');
    var btnGoTo = $(this).parent().parent().find("li a");
    $(btnGoTo).removeClass('active');
    $(this).addClass('active');
    $('html, body').animate({
        scrollTop: $(getId).offset().top - 0
    }, 1000);

  });